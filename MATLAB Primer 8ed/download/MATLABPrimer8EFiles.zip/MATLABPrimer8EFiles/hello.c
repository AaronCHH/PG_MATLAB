#include "mex.h"
void mexFunction
(
    int nargout,
    mxArray *pargout [ ],
    int nargin,
    const mxArray *pargin [ ]
)
{
    mexPrintf ("hello world\n") ;
}

