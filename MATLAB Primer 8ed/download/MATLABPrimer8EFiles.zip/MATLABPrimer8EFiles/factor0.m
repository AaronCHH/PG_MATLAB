classdef factor0
    % FACTOR0  my first object
    properties
        L, U ;
    end
end
