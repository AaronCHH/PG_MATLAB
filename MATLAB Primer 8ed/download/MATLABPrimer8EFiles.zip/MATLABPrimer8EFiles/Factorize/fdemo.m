% Run the factorize demo
echodemo ('factorize_demo') ;
